
<?php
       
       include('connection.php');
       include('header.php');
       
        ?>   
<body>

    <div id="wrapper" style="padding-left:0px">

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           PHP CRUD <small>Create, Read, Update and Delete</small>
                        </h1>
                       
                    </div>
                </div>
                <!-- /.row -->


             <div class="col-lg-12">
                <?php
						$fname = $_POST['firstname'];
					    $lname = $_POST['lastname'];
						$bday = $_POST['birthday'];
						$address = $_POST['Address'];
						$telephone = $_POST['telephone'];
						$gender = $_POST['gender'];
				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO person  
								(id, first_name, last_name, birthday, address, telephone, gender)
								VALUES (NULL, '".$fname."','".$lname."','".$bday."','".$address."','".$telephone."','".$gender."')";
								if (mysqli_query($db, $query)) {
                                    echo "New record created successfully";
                                    } else {
                                die( "Error: " . $query . "<br>" . mysqli_error($db));
                                    }
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "index.php";
		</script>
                    </div>
                </div>
                
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>

