<?php
 $db = mysqli_connect('sql111.unaux.com', 'unaux_30386183', '9qm0digve8bv') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, 'unaux_30386183_mydb' ) or die(mysqli_error($db));
?>